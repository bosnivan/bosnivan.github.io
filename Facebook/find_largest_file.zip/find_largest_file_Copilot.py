import os

def find_largest_file(folder_path):
    folder_path = os.path.abspath(folder_path)
    max_size = 0
    max_file = ""

    for folder, _, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(folder, file)
            size = os.stat(file_path).st_size
            if size > max_size:
                max_size = size
                max_file = file_path

    print("The largest file is:", max_file)
    print("Size:", max_size, "bytes")

# Example usage:
folder_to_check = input("Enter folder path: ")
find_largest_file(folder_to_check)
