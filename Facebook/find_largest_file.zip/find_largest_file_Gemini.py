import os

def find_largest_file(folder_path):
  """
  Finds the largest file in a folder and its subfolders.

  Args:
      folder_path: The path to the folder to search.

  Returns:
      The path to the largest file, or None if no files are found.
  """
  largest_file = None
  largest_size = 0

  for root, _, files in os.walk(folder_path):
    for filename in files:
      file_path = os.path.join(root, filename)
      try:
        file_size = os.path.getsize(file_path)
        if file_size > largest_size:
          largest_file = file_path
          largest_size = file_size
      except OSError:
        # Handle potential errors like permission issues
        pass

  return largest_file

# Example usage
folder_path = "C:\\Movies"  # Replace with your desired folder path
largest_file = find_largest_file(folder_path)

if largest_file:
  print(f"The largest file is: {largest_file}")
else:
  print("No files found in the folder or its subfolders.")
