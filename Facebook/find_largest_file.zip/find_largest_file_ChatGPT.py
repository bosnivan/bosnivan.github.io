import os

def find_largest_file(directory):
    largest_file_path = ''
    largest_file_size = 0

    # Walk through all directories and files in the specified directory
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                file_size = os.path.getsize(file_path)
                if file_size > largest_file_size:
                    largest_file_size = file_size
                    largest_file_path = file_path
            except OSError as e:
                print(f"Error accessing file: {file_path}. Error: {e}")

    return largest_file_path, largest_file_size

if __name__ == "__main__":
    folder_path = input("Enter the path of the folder: ").strip()
    largest_file, size = find_largest_file(folder_path)
    if largest_file:
        print(f"The largest file is: {largest_file} with a size of {size} bytes.")
    else:
        print("No files found in the specified directory.")
